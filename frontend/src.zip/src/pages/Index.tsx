import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import SkillMarketplaceSection from "@/components/SkillMarketplaceSection";
import FocusModeSection from "@/components/FocusModeSection";
import LocationBasedSection from "@/components/LocationBasedSection";
import AISuggestionsSection from "@/components/AISuggestionsSection";
import ResumeBuilderSection from "@/components/ResumeBuilderSection";
import CommunitySection from "@/components/CommunitySection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <SkillMarketplaceSection />
      <FocusModeSection />
      <LocationBasedSection />
      <AISuggestionsSection />
      <ResumeBuilderSection />
      <CommunitySection />
      <Footer />
    </div>
  );
};

export default Index;
