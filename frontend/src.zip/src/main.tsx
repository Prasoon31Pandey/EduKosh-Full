// main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { GoogleOAuthProvider } from '@react-oauth/google';
import './index.css';

// Replace with your actual Google Client ID
const clientId = '407041518258-jufb40qsgigdegs2njc8s11o6gj1g3oo.apps.googleusercontent.com';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <GoogleOAuthProvider clientId={clientId}>
      <App />
    </GoogleOAuthProvider>
  </React.StrictMode>
);
import Navbar from "@/components/Navigation"; // import the Navbar component
// your other imports

const Index = () => {
  return (
    <>
      <Navbar />
      {/* rest of your homepage */}
      <div className="p-4">Welcome to the dental clinic website!</div>
    </>
  );
};

export default Index;
