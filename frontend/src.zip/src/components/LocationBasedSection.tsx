import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  MapPin, 
  Navigation, 
  Users, 
  Clock,
  Star,
  Video,
  Coffee,
  Home,
  Building
} from "lucide-react";

const nearbyLearners = [
  {
    name: "Arjun Patel",
    skill: "Web Development",
    distance: "0.8 km",
    type: "Teaching",
    rating: 4.8,
    sessionType: "In-person",
    location: "Coffee House, MG Road",
    image: "👨‍💻",
    karma: 850
  },
  {
    name: "Sneha Reddy", 
    skill: "Yoga & Meditation",
    distance: "1.2 km",
    type: "Teaching",
    rating: 4.9,
    sessionType: "Park/Online",
    location: "Lalbagh Botanical Garden",
    image: "🧘‍♀️",
    karma: 650
  },
  {
    name: "Vikram Singh",
    skill: "Guitar Lessons", 
    distance: "2.1 km",
    type: "Learning",
    rating: 4.7,
    sessionType: "Home",
    location: "Whitefield area",
    image: "🎸",
    karma: 420
  }
];

const LocationBasedSection = () => {
  return (
    <section id="location-based" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="inline-flex items-center space-x-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium">
              <MapPin className="w-4 h-4" />
              <span>Location-Based Learning</span>
            </div>
            
            <h2 className="text-3xl md:text-5xl font-bold text-foreground">
              Learn from{" "}
              <span className="text-transparent bg-gradient-primary bg-clip-text">
                People Near You
              </span>
            </h2>
            
            <p className="text-xl text-muted-foreground">
              Connect with skilled learners and teachers in your neighborhood. Whether you prefer 
              in-person sessions at a local café or online lessons, find the perfect learning 
              companion nearby.
            </p>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="text-muted-foreground">Auto-detect location or enter your PIN code</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-accent rounded-full"></div>
                <span className="text-muted-foreground">Filter by distance: 1km, 5km, 10km radius</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-secondary rounded-full"></div>
                <span className="text-muted-foreground">Choose in-person, online, or hybrid sessions</span>
              </div>
            </div>

            {/* Location Controls */}
            <div className="bg-muted/30 rounded-xl p-6 space-y-4">
              <h3 className="font-semibold text-foreground mb-4">Find learners near you</h3>
              <div className="flex space-x-3">
                <div className="flex-1">
                  <input 
                    type="text" 
                    placeholder="Enter your location or PIN code"
                    className="w-full px-4 py-3 bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
                <Button variant="default">
                  <Navigation className="w-4 h-4 mr-2" />
                  Detect
                </Button>
              </div>
              
              <div className="flex space-x-2">
                <Button variant="soft" size="sm">1 km</Button>
                <Button variant="soft" size="sm">5 km</Button>
                <Button variant="outline" size="sm">10 km</Button>
              </div>
            </div>

            <Button variant="hero" size="lg" className="group">
              <Users className="w-5 h-5 mr-2" />
              Explore Nearby Learning
            </Button>
          </div>

          {/* Right - Nearby People Cards */}
          <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-foreground">People Near You</h3>
              <span className="text-sm text-muted-foreground">📍 Bangalore, Karnataka</span>
            </div>

            {nearbyLearners.map((person, index) => (
              <Card 
                key={person.name}
                className="p-6 bg-gradient-card border-border/50 hover:shadow-grow hover:scale-102 transition-all cursor-pointer group"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start space-x-4">
                  <div className="text-3xl">{person.image}</div>
                  
                  <div className="flex-1 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                          {person.name}
                        </h4>
                        <p className="text-sm text-muted-foreground">{person.skill}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{person.rating}</span>
                        </div>
                        <div className="text-xs text-muted-foreground">{person.karma} karma</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{person.distance}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        {person.sessionType === "In-person" ? <Coffee className="w-4 h-4" /> :
                         person.sessionType === "Home" ? <Home className="w-4 h-4" /> :
                         person.sessionType === "Park/Online" ? <Building className="w-4 h-4" /> :
                         <Video className="w-4 h-4" />}
                        <span>{person.sessionType}</span>
                      </div>
                    </div>
                    
                    <div className="text-sm text-muted-foreground">
                      📍 {person.location}
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        person.type === "Teaching" 
                          ? "bg-primary/20 text-primary" 
                          : "bg-accent/20 text-accent"
                      }`}>
                        {person.type}
                      </span>
                      <Button variant="soft" size="sm">
                        {person.type === "Teaching" ? "Learn" : "Connect"}
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}

            <Card className="p-6 bg-gradient-hero border-border/50 text-center">
              <Users className="w-8 h-8 text-primary mx-auto mb-3" />
              <h4 className="font-semibold text-foreground mb-2">Join Your Local Community</h4>
              <p className="text-sm text-muted-foreground mb-4">
                Connect with 150+ active learners in your area
              </p>
              <Button variant="floating" size="sm">View All</Button>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LocationBasedSection;