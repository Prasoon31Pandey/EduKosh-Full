import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Timer, Sprout, TrendingUp, Award, Play, TreePine, Crown } from "lucide-react";

const plantStages = [
  { time: "0-15min", emoji: "🌱", name: "Seedling", karma: 10 },
  { time: "15-30min", emoji: "🌿", name: "Sprout", karma: 25 },
  { time: "30-45min", emoji: "🪴", name: "Young Plant", karma: 50 },
  { time: "45-60min", emoji: "🌳", name: "Mighty Tree", karma: 100, bonus: "+50 bonus!" }
];

const FocusModeSection = () => {
  return (
    <section id="focus-mode" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="inline-flex items-center space-x-2 bg-accent/20 text-accent px-4 py-2 rounded-full text-sm font-medium">
              <Timer className="w-4 h-4" />
              <span>Focus Mode with Plant Evolution</span>
            </div>
            
            <h2 className="text-3xl md:text-5xl font-bold text-foreground">
              Watch Your{" "}
              <span className="text-transparent bg-gradient-primary bg-clip-text">
                Garden Grow
              </span>{" "}
              as You Learn
            </h2>
            
            <p className="text-xl text-muted-foreground">
              Our revolutionary focus timer doesn't just track time - it evolves your virtual plants 
              as you study. Reach the full hour to grow a mighty tree and earn massive karma rewards!
            </p>

            {/* Plant Evolution Stages */}
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground mb-4">Plant Evolution Stages:</h3>
              {plantStages.map((stage, index) => (
                <div key={stage.name} className="flex items-center space-x-4 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                  <span className="text-2xl">{stage.emoji}</span>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-foreground">{stage.name}</span>
                      <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded-full">{stage.time}</span>
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-sm text-muted-foreground">+{stage.karma} karma</span>
                      {stage.bonus && (
                        <span className="text-xs bg-accent/20 text-accent px-2 py-1 rounded-full font-semibold">
                          {stage.bonus}
                        </span>
                      )}
                    </div>
                  </div>
                  {index === plantStages.length - 1 && (
                    <Crown className="w-5 h-5 text-accent" />
                  )}
                </div>
              ))}
            </div>

            <div className="flex items-center space-x-4 p-4 bg-primary-light/20 rounded-xl border border-primary/20">
              <TreePine className="w-6 h-6 text-primary" />
              <div>
                <div className="font-semibold text-primary">Study for 1 Hour = Tree + Leaderboard Boost!</div>
                <div className="text-sm text-muted-foreground">Unlock maximum karma and premium visibility</div>
              </div>
            </div>

            <Button variant="hero" size="lg" className="group">
              <Play className="w-5 h-5 mr-2" />
              Start Growing Your Garden
            </Button>
          </div>

          {/* Right Demo Cards */}
          <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            {/* Main Timer Card */}
            <Card className="p-8 bg-gradient-card border-border/50 hover:shadow-grow transition-all text-center">
              <div className="flex items-center justify-between mb-6">
                <Timer className="w-6 h-6 text-primary" />
                <span className="text-xs bg-primary/20 text-primary px-3 py-1 rounded-full font-medium">Active Session</span>
              </div>
              <div className="space-y-4">
                <div className="text-6xl animate-pulse-grow">🌿</div>
                <div className="text-3xl font-bold text-foreground">43:12</div>
                <div className="text-muted-foreground">Growing into Young Plant...</div>
                <div className="w-full bg-muted rounded-full h-3">
                  <div className="bg-gradient-primary h-3 rounded-full w-3/4 transition-all"></div>
                </div>
                <div className="text-sm text-primary font-medium">+50 karma earned so far</div>
              </div>
            </Card>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4 bg-gradient-card border-border/50 hover:shadow-grow transition-all text-center">
                <TrendingUp className="w-5 h-5 text-secondary mx-auto mb-2" />
                <div className="text-xl font-bold text-foreground">4.5h</div>
                <div className="text-sm text-muted-foreground">Today's Focus</div>
              </Card>

              <Card className="p-4 bg-gradient-card border-border/50 hover:shadow-grow transition-all text-center">
                <Award className="w-5 h-5 text-accent mx-auto mb-2" />
                <div className="text-xl font-bold text-foreground">12🔥</div>
                <div className="text-sm text-muted-foreground">Day Streak</div>
              </Card>

              <Card className="p-4 bg-gradient-card border-border/50 hover:shadow-grow transition-all text-center">
                <TreePine className="w-5 h-5 text-primary mx-auto mb-2" />
                <div className="text-xl font-bold text-foreground">3🌳</div>
                <div className="text-sm text-muted-foreground">Trees Grown</div>
              </Card>

              <Card className="p-4 bg-gradient-card border-border/50 hover:shadow-grow transition-all text-center">
                <Crown className="w-5 h-5 text-primary-glow mx-auto mb-2" />
                <div className="text-xl font-bold text-foreground">1,250</div>
                <div className="text-sm text-muted-foreground">Total Karma</div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FocusModeSection;